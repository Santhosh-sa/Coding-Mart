<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png" width="25%">
    <HelloWorld msg="Hello Vue in C!"/>
  </div>
</template>

<script>
import HelloWorld from "./components/HelloWorld";

export default {
  name: "App",
  components: {
    HelloWorld
  }
};
</script>

<style>
body{
  background-color:grey;
    width: 400px;
    border:  black;
    padding-top: 150px;
    padding-left: 500px;
    padding-right: 600px;
    padding-bottom: 170px;
}
label {
  color:solid black;
  padding-right: 3%;
  padding-left: 3%;
  text-align: justiy;;
}
button {
  border: none;
  border-radius: 20px;
  width:150px;
  padding:10px;
}
from{
    width: 400px;
    border: solid black;
    padding: 50px;
    margin: 10px;
    border-spacing: 400px;
}
</style>
